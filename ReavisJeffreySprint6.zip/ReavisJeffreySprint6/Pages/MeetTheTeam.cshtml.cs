using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ReavisJeffreySprint6.Pages
{
    public class MeetTheTeamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
