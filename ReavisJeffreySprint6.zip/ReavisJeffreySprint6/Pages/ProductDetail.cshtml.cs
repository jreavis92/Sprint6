using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ReavisJeffreySprint6.Data;
using ReavisJeffreySprint6.Data.Entities;

namespace ReavisJeffreySprint6.Pages
{
    public class ProductDetailModel : PageModel
    {
        //Bringing in the details of the products... 
        public List<vw_AllProductDetails> onecandle = new List<vw_AllProductDetails>();

        //Do the same but bring in the view... not sure if this is what needs to be done, but this is what was done in the video
        public List<vw_AllProductReviews> reviews = new List<vw_AllProductReviews>();

        //Need a readonly variable to be the same name as whatever you called your DbContext class.
        private readonly ApplicationDbContext _ApplicationDbContext;
        //The following code injects our database context into our page model
        public ProductDetailModel(ApplicationDbContext myApplicationDbContext)
        {
            _ApplicationDbContext = myApplicationDbContext;
        }
        //The OnGet Async executes prior to the user seeing the page
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            //Retrieve the one selected class whose ProductID was passed as a parameter using asp-route-id
            onecandle = await _ApplicationDbContext.vw_AllProductDetails.Where(x => x.ProductID == id).ToListAsync();

            reviews = await _ApplicationDbContext.vw_AllProductReviews.Where(x => x.ProductID == id).ToListAsync(); 

            return Page();
        }
    }
}
