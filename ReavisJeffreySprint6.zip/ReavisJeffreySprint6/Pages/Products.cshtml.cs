using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ReavisJeffreySprint6.Data;
using ReavisJeffreySprint6.Data.Entities;

namespace ReavisJeffreySprint6.Pages
{
    public class ProductsModel : PageModel
    {
        //Need a readonly variable to be the same name as whatever you called your DbContext class.
        private readonly ApplicationDbContext _ApplicationDbContext;
        //The following code injects our database context into our page model
        public ProductsModel(ApplicationDbContext myApplicationDbContext)
        {
            _ApplicationDbContext = myApplicationDbContext;
        }

        public List<Products> allcandles = new List<Products>();

        //The OnGet Async executes prior to the user seeing the page
        public async Task<IActionResult> OnGetAsync()
        {
            //Populate the allcandles list that we created above
            allcandles = await _ApplicationDbContext.Products.ToListAsync();

            return Page();
        }
    }
}
