﻿using Microsoft.EntityFrameworkCore;
using ReavisJeffreySprint6.Data.Entities;
namespace ReavisJeffreySprint6.Data;


public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<vw_AllProductDetails> vw_AllProductDetails { get; set; }
    public DbSet<vw_AllProductReviews> vw_AllProductReviews { get; set; }
    public DbSet<ScentMaster> ScentMaster { get; set; }
    public DbSet<RatingSystem> RatingSystem { get; set; }
    public DbSet<Products> Products { get; set; }
    public DbSet<ProductReviews> ProductReviews { get; set; }
    public DbSet<MaterialMaster> MaterialMaster { get; set; }
    public DbSet<ColorMaster> ColorMaster { get; set; }
}