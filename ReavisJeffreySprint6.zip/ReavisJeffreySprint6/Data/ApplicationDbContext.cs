﻿using Microsoft.EntityFrameworkCore;
namespace ReavisJeffreySprint6.Data;


public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Classes> Classes { get; set; }
}