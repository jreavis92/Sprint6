﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreySprint6.Data.Entities
{
    public class ScentMaster
    {
        [Key]
        public int ScentID { get; set; }
        public string ScentName { get; set; }
    }
}
