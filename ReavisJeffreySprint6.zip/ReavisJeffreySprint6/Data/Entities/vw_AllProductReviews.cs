﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreySprint6.Data.Entities
{
    public class vw_AllProductReviews
    {

        [Key]
        public int ReviewID { get; set; }
        public int ProductID { get; set; }

        public string CustomerName { get; set; }
        public string ReviewText { get; set; }
        public int StarsID { get; set; }

        public string StarImagePath { get; set; }
    }
}
