﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreySprint6.Data.Entities
{
    public class MaterialMaster
    {
        [Key]
        public int MaterialID { get; set; }
        public string MaterialName { get; set; }
    }
}
