﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreySprint6.Data.Entities
{
    public class ColorMaster
    {
        [Key]
        public int ColorID { get; set; }
        public string ColorName { get; set; }
    }
}
