﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreySprint6.Data.Entities
{
    public class ProductReviews
    { 
        [Key]
        public int ReviewID { get; set; }
        public int ProductID { get; set; }
        public string CustomerName { get; set; }
        public string ReviewText { get; set; }
        public int RatingID { get; set; }
    }
}
