﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreySprint6.Data.Entities
{
    public class vw_AllProductDetails
    {
        [Key]
        public int ProductID { get; set; }
        public string ProductName  { get; set; }
        public string ProductDescription{ get; set; }
        public int ScentID { get; set; }
        public string ScentName { get; set; }
        public int ColorID { get; set; }
        public string ColorName { get; set; }
        public int MaterialID { get; set; }
        public string MaterialName { get; set; }
        public decimal Price { get; set; }
        public string ProductImagePath { get; set; }

    }
}
