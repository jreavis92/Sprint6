﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreySprint6.Data.Entities
{
    public class RatingSystem
    {
        [Key]
        public int RatingID { get; set; }
        public int StarsID { get; set; }
        public string StarImagePath { get; set; }
    }
}
